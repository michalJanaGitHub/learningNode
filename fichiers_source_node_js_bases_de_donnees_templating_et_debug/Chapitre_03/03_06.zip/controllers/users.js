exports.index = function (req, res) {
    var returnResponse = function (collection) {
        res.json(collection);
    };

    models.User.find().sort({name:1}).limit(2).execAsync()
        .then(logLib.logContent)
        .then(returnResponse)
    ;
};

exports.one = function (req, res) {
    var options = {name: req.params.name};
    var returnResponse = function (obj) {
        res.json(obj);
    };

    models.User.findOneAsync(options)
        .then(logLib.logContent)
        .then(returnResponse)
    ;
};