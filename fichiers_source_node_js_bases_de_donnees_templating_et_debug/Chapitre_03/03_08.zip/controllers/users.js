exports.index = function (req, res) {
    var returnResponse = function (obj) {
        res.json(obj);
    };

    models.User.find().sort({name:1}).select('-_id').execAsync()
        .then(logLib.logContent)
        .then(returnResponse)
    ;
};

exports.one = function (req, res) {
    var returnResponse = function (obj) {
        res.json(obj);
    };

    var options = {name: req.params.name};

    models.User.findOneAsync(options)
        .then(logLib.logContent)
        .then(returnResponse)
    ;
};

exports.create = function (req, res) {
    var returnResponse = function (obj) {
        res.json(obj);
    };

    var user = models.User(req.body).saveAsync()
        .then(logLib.logContent)
        .then(returnResponse);
};