exports.schema = new mongoose.Schema({
        name: String,
        lastname: String,
        age: String,
        job: String,
        tel: String
    }
)