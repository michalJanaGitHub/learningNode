var callback = require('../controllers/callback');

app.get('/callback', callback.index);