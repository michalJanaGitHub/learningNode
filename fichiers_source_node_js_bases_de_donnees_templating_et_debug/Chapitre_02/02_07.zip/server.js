var path = require('path');
var express = require('express');
Promise = require('bluebird');
fs = Promise.promisifyAll(require('fs'));
logLib = require('./lib/log');
app = express();

app.use(express.static('public'));

// import routing
require('./routing/callback');
require('./routing/users');

app.listen(8080);