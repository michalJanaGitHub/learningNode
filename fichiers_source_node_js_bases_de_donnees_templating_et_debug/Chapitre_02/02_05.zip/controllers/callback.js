/**
 * Index Action
 *
 * @param req
 * @param res
 */
exports.index = function (req, res) {
    var returnResponseOfFileJson = function (content) {
        res.json(content);
    };

    fs.readFileAsync('testddd.json')
        .then(logLib.logContentOfFile)
        .then(JSON.parse)
        .then(returnResponseOfFileJson)
    ;

    console.log('autre chose');
};